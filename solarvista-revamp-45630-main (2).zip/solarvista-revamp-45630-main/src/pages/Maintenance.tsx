import { Link } from "react-router-dom";
import { ArrowRight, Wrench, Eye, Droplets, Activity, Clock, Shield } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useLanguage } from "@/contexts/LanguageContext";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import maintenanceTeam from "@/assets/maintenance-team.jpg";
import customerConsultation from "@/assets/customer-consultation.jpg";

const Maintenance = () => {
  const { t } = useLanguage();
  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      {/* Hero Section - Split Layout for Maintenance */}
      <section className="relative min-h-[600px] overflow-hidden">
        <div className="grid md:grid-cols-2 h-full">
          {/* Left: Content */}
          <div className="bg-gradient-to-br from-secondary via-primary to-accent p-8 md:p-16 flex items-center">
            <div className="max-w-xl animate-fade-in-up">
              <div className="inline-flex items-center gap-2 bg-white/20 backdrop-blur-sm px-4 py-2 rounded-full mb-6">
                <Wrench className="w-5 h-5 text-white" />
                <span className="text-sm font-semibold text-white">{t('maintenance.hero.badge')}</span>
              </div>
              <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
                {t('maintenance.hero.title')}
                <span className="block text-white/90 mt-2">{t('maintenance.hero.subtitle')}</span>
              </h1>
              <p className="text-lg md:text-xl text-white/90 mb-8">
                {t('maintenance.hero.desc')}
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button variant="default" size="lg" className="bg-white text-primary hover:bg-white/90" asChild>
                  <Link to="/contact">
                    Schedule Maintenance <ArrowRight className="ml-2" />
                  </Link>
                </Button>
                <Button variant="outline" size="lg" className="border-white text-white hover:bg-white/10" asChild>
                  <Link to="/contact">Get Quote</Link>
                </Button>
              </div>
            </div>
          </div>
          
          {/* Right: Animated Image Collage */}
          <div className="relative hidden md:block">
            <div className="absolute inset-0 grid grid-cols-2 gap-2 p-4">
              <div className="overflow-hidden rounded-2xl animate-fade-in-up">
                <img src={maintenanceTeam} alt="Solar maintenance" className="w-full h-full object-cover hover:scale-110 transition-transform duration-500" loading="lazy" />
              </div>
              <div className="overflow-hidden rounded-2xl animate-fade-in-up" style={{ animationDelay: "0.2s" }}>
                <img src={customerConsultation} alt="Panel cleaning" className="w-full h-full object-cover hover:scale-110 transition-transform duration-500" loading="lazy" />
              </div>
              <div className="overflow-hidden rounded-2xl animate-fade-in-up" style={{ animationDelay: "0.4s" }}>
                <img src={maintenanceTeam} alt="Monitoring" className="w-full h-full object-cover hover:scale-110 transition-transform duration-500" loading="lazy" />
              </div>
              <div className="overflow-hidden rounded-2xl animate-fade-in-up" style={{ animationDelay: "0.6s" }}>
                <img src={customerConsultation} alt="Support" className="w-full h-full object-cover hover:scale-110 transition-transform duration-500" loading="lazy" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Why Maintenance Matters */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Why <span className="gradient-text">Regular Maintenance</span> Matters
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Proper maintenance ensures maximum energy output and extends system lifespan
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <Card className="hover-lift border-2 text-center">
              <CardHeader>
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Activity className="w-8 h-8 text-primary" />
                </div>
                <CardTitle>20-30% More Output</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Clean panels generate significantly more electricity than dirty ones
                </p>
              </CardContent>
            </Card>

            <Card className="hover-lift border-2 text-center">
              <CardHeader>
                <div className="w-16 h-16 bg-secondary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Shield className="w-8 h-8 text-secondary" />
                </div>
                <CardTitle>Extended Lifespan</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Regular maintenance can extend system life from 25 to 30+ years
                </p>
              </CardContent>
            </Card>

            <Card className="hover-lift border-2 text-center">
              <CardHeader>
                <div className="w-16 h-16 bg-accent/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Clock className="w-8 h-8 text-accent" />
                </div>
                <CardTitle>Prevent Downtime</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Early detection of issues prevents costly repairs and energy loss
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Our Services */}
      <section className="py-20 bg-muted/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Our <span className="gradient-text">Maintenance Services</span>
            </h2>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            <Card className="border-2 hover-lift">
              <CardHeader className="bg-primary text-primary-foreground">
                <CardTitle className="flex items-center gap-2 text-2xl">
                  <Droplets className="w-6 h-6" />
                  Panel Cleaning Service
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6 space-y-4">
                <p className="text-foreground">
                  Professional cleaning to remove dust, bird droppings, and debris that reduce efficiency.
                </p>
                <ul className="space-y-2">
                  <li className="flex items-start gap-2">
                    <span className="text-secondary font-bold">✓</span>
                    <span>Waterless or water-based cleaning methods</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-secondary font-bold">✓</span>
                    <span>Safe cleaning agents that don't damage panels</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-secondary font-bold">✓</span>
                    <span>Quarterly cleaning schedule recommended</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-secondary font-bold">✓</span>
                    <span>Before/after output comparison reports</span>
                  </li>
                </ul>
                <div className="pt-4">
                  <p className="text-sm font-semibold">Starting from ₹2/watt</p>
                </div>
              </CardContent>
            </Card>

            <Card className="border-2 hover-lift">
              <CardHeader className="bg-secondary text-secondary-foreground">
                <CardTitle className="flex items-center gap-2 text-2xl">
                  <Eye className="w-6 h-6" />
                  24/7 Monitoring System
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6 space-y-4">
                <p className="text-foreground">
                  Real-time monitoring to track performance and detect issues instantly.
                </p>
                <ul className="space-y-2">
                  <li className="flex items-start gap-2">
                    <span className="text-primary font-bold">✓</span>
                    <span>Cloud-based monitoring platform</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-primary font-bold">✓</span>
                    <span>Mobile app access for real-time data</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-primary font-bold">✓</span>
                    <span>Instant alerts for system failures</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-primary font-bold">✓</span>
                    <span>Daily, weekly, and monthly reports</span>
                  </li>
                </ul>
                <div className="pt-4">
                  <p className="text-sm font-semibold">Custom monitoring fee</p>
                </div>
              </CardContent>
            </Card>

            <Card className="border-2 hover-lift">
              <CardHeader className="bg-accent text-accent-foreground">
                <CardTitle className="flex items-center gap-2 text-2xl">
                  <Wrench className="w-6 h-6" />
                  Regular Check-ups
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6 space-y-4">
                <p className="text-foreground">
                  Comprehensive system inspections to ensure optimal performance.
                </p>
                <ul className="space-y-2">
                  <li className="flex items-start gap-2">
                    <span className="text-secondary font-bold">✓</span>
                    <span>Inverter health and performance check</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-secondary font-bold">✓</span>
                    <span>Electrical connection inspection</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-secondary font-bold">✓</span>
                    <span>Mounting structure stability check</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-secondary font-bold">✓</span>
                    <span>Panel hotspot detection using thermal imaging</span>
                  </li>
                </ul>
                <div className="pt-4">
                  <p className="text-sm font-semibold">Bi-annual inspection: ₹3,000/visit</p>
                </div>
              </CardContent>
            </Card>

            <Card className="border-2 hover-lift">
              <CardHeader className="bg-cta text-cta-foreground">
                <CardTitle className="flex items-center gap-2 text-2xl">
                  <Activity className="w-6 h-6" />
                  Troubleshooting & Repair
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6 space-y-4">
                <p className="text-foreground">
                  Quick response to system issues with expert technical support.
                </p>
                <ul className="space-y-2">
                  <li className="flex items-start gap-2">
                    <span className="text-secondary font-bold">✓</span>
                    <span>24-hour emergency response</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-secondary font-bold">✓</span>
                    <span>Inverter replacement and repairs</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-secondary font-bold">✓</span>
                    <span>Panel replacement (if under warranty)</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-secondary font-bold">✓</span>
                    <span>Wiring and connection fixes</span>
                  </li>
                </ul>
                <div className="pt-4">
                  <p className="text-sm font-semibold">On-demand pricing based on issue</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* AMC Packages */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Annual <span className="gradient-text">Maintenance Packages</span>
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Choose a comprehensive package and save up to 30% on maintenance costs
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <Card className="border-2 hover-lift">
              <CardHeader className="text-center">
                <CardTitle className="text-2xl">Basic</CardTitle>
                <p className="text-3xl font-bold text-primary mt-2">₹4,999<span className="text-base font-normal text-muted-foreground">/year</span></p>
              </CardHeader>
              <CardContent className="space-y-3">
                <p className="text-sm text-muted-foreground text-center mb-4">Perfect for small systems (up to 3kW)</p>
                <ul className="space-y-2">
                  <li className="flex items-start gap-2">
                    <span className="text-secondary font-bold">✓</span>
                    <span className="text-sm">2 cleaning sessions/year</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-secondary font-bold">✓</span>
                    <span className="text-sm">1 system inspection</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-secondary font-bold">✓</span>
                    <span className="text-sm">Email performance reports</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-secondary font-bold">✓</span>
                    <span className="text-sm">Phone support</span>
                  </li>
                </ul>
                <Button variant="outline" className="w-full mt-4" asChild>
                  <Link to="/contact">Choose Plan</Link>
                </Button>
              </CardContent>
            </Card>

            <Card className="border-4 border-primary hover-lift relative">
              <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-primary text-primary-foreground px-4 py-1 rounded-full text-sm font-semibold">
                Most Popular
              </div>
              <CardHeader className="text-center pt-6">
                <CardTitle className="text-2xl">Standard</CardTitle>
                <p className="text-3xl font-bold text-primary mt-2">₹7,999<span className="text-base font-normal text-muted-foreground">/year</span></p>
              </CardHeader>
              <CardContent className="space-y-3">
                <p className="text-sm text-muted-foreground text-center mb-4">Best value for 3-5kW systems</p>
                <ul className="space-y-2">
                  <li className="flex items-start gap-2">
                    <span className="text-secondary font-bold">✓</span>
                    <span className="text-sm">4 cleaning sessions/year</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-secondary font-bold">✓</span>
                    <span className="text-sm">2 comprehensive inspections</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-secondary font-bold">✓</span>
                    <span className="text-sm">24/7 monitoring included</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-secondary font-bold">✓</span>
                    <span className="text-sm">Priority support</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-secondary font-bold">✓</span>
                    <span className="text-sm">20% discount on repairs</span>
                  </li>
                </ul>
                <Button variant="cta" className="w-full mt-4" asChild>
                  <Link to="/contact">Choose Plan</Link>
                </Button>
              </CardContent>
            </Card>

            <Card className="border-2 hover-lift">
              <CardHeader className="text-center">
                <CardTitle className="text-2xl">Premium</CardTitle>
                <p className="text-3xl font-bold text-primary mt-2">₹12,999<span className="text-base font-normal text-muted-foreground">/year</span></p>
              </CardHeader>
              <CardContent className="space-y-3">
                <p className="text-sm text-muted-foreground text-center mb-4">Complete care for 5kW+ systems</p>
                <ul className="space-y-2">
                  <li className="flex items-start gap-2">
                    <span className="text-secondary font-bold">✓</span>
                    <span className="text-sm">6 cleaning sessions/year</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-secondary font-bold">✓</span>
                    <span className="text-sm">4 comprehensive inspections</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-secondary font-bold">✓</span>
                    <span className="text-sm">24/7 monitoring + alerts</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-secondary font-bold">✓</span>
                    <span className="text-sm">VIP support (2-hour response)</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-secondary font-bold">✓</span>
                    <span className="text-sm">30% discount on repairs</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-secondary font-bold">✓</span>
                    <span className="text-sm">Free thermal imaging check</span>
                  </li>
                </ul>
                <Button variant="outline" className="w-full mt-4" asChild>
                  <Link to="/contact">Choose Plan</Link>
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Request Form CTA */}
      <section className="py-20 bg-gradient-solar">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <Wrench className="w-16 h-16 text-white mx-auto mb-6 animate-float" />
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Schedule Your Maintenance Today
          </h2>
          <p className="text-lg text-white/90 mb-8 max-w-2xl mx-auto">
            Keep your solar system performing at its best with our professional maintenance services
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button variant="default" size="lg" className="bg-white text-primary hover:bg-white/90" asChild>
              <Link to="/contact">
                Request Maintenance <ArrowRight className="ml-2" />
              </Link>
            </Button>
            <Button variant="outline" size="lg" className="border-white text-white hover:bg-white hover:text-primary" asChild>
              <Link to="/contact">Call +91 73806 07555</Link>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Maintenance;
