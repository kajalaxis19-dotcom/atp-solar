import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { Sun, Battery, Zap, Shield, Award, CheckCircle } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";
import solarProducts from "@/assets/solar-products.jpg";
import solarPanelCloseup from "@/assets/solar-panel-closeup.jpg";
import commercialInstall from "@/assets/commercial-install.jpg";

const Products = () => {
  const { t } = useLanguage();
  
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      {/* Hero - Product Showcase */}
      <section className="relative py-20 overflow-hidden bg-gradient-to-br from-primary/5 to-secondary/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-6 animate-fade-in">
              <div className="inline-flex items-center gap-2 px-4 py-2 bg-accent/10 rounded-full border border-accent/20">
                <Sun className="w-5 h-5 text-accent" />
                <span className="text-sm font-semibold text-accent">Premium Solar Products</span>
              </div>
              <h1 className="text-5xl md:text-6xl font-bold">
                {t('products.hero.title')} <span className="gradient-text">{t('products.hero.titleHighlight')}</span>
              </h1>
              <p className="text-xl text-muted-foreground">
                {t('products.hero.subtitle')}
              </p>
              <Button variant="cta" size="lg" asChild>
                <Link to="/contact">{t('products.hero.cta') || 'Get Product Consultation'}</Link>
              </Button>
            </div>
            <div className="relative group">
              <div className="absolute inset-0 bg-gradient-solar rounded-2xl blur-3xl opacity-20 group-hover:opacity-30 transition-all"></div>
              <img 
                src={solarProducts} 
                alt="Solar Products" 
                className="relative w-full rounded-2xl shadow-2xl transform group-hover:scale-105 transition-all duration-500"
                loading="eager"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Solar Panels */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-solar shadow-lg">
                <Sun className="w-8 h-8 text-white" />
              </div>
              <h2 className="text-4xl font-bold">{t('products.panels.title')}</h2>
              <p className="text-lg text-muted-foreground">
                Industry-leading efficiency with premium monocrystalline technology. Our panels deliver maximum power output even in low-light conditions.
              </p>
              <div className="space-y-3">
                {[
                  "21%+ module efficiency",
                  "540-550W high-power modules",
                  "25-year linear performance warranty",
                  "IEC/CE/ISO certified",
                  "PID & LID resistant technology",
                  "Withstands up to 2400 Pa snow load"
                ].map((feature, index) => (
                  <div key={index} className="flex items-center gap-3 group">
                    <CheckCircle className="w-6 h-6 text-primary flex-shrink-0 group-hover:scale-110 transition-transform" />
                    <span className="text-foreground">{feature}</span>
                  </div>
                ))}
              </div>
              <div className="grid grid-cols-3 gap-4 pt-4">
                <div className="text-center p-4 bg-muted/30 rounded-lg">
                  <div className="text-3xl font-bold gradient-text">25+</div>
                  <div className="text-sm text-muted-foreground">Years Lifespan</div>
                </div>
                <div className="text-center p-4 bg-muted/30 rounded-lg">
                  <div className="text-3xl font-bold gradient-text">21%</div>
                  <div className="text-sm text-muted-foreground">Efficiency</div>
                </div>
                <div className="text-center p-4 bg-muted/30 rounded-lg">
                  <div className="text-3xl font-bold gradient-text">550W</div>
                  <div className="text-sm text-muted-foreground">Max Power</div>
                </div>
              </div>
            </div>
            <div className="relative">
              <div className="relative overflow-hidden rounded-2xl shadow-2xl group">
                <img 
                  src={solarPanelCloseup} 
                  alt="Solar Panel" 
                  className="w-full transform group-hover:scale-110 transition-all duration-700"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Inverters */}
      <section className="py-20 bg-muted/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="order-2 lg:order-1 relative">
              <div className="relative overflow-hidden rounded-2xl shadow-2xl">
                <img 
                  src={commercialInstall} 
                  alt="Inverter Installation" 
                  className="w-full transform hover:scale-105 transition-all duration-500"
                  loading="lazy"
                />
              </div>
            </div>
            <div className="order-1 lg:order-2 space-y-6">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-secondary to-secondary-dark shadow-lg">
                <Zap className="w-8 h-8 text-white" />
              </div>
              <h2 className="text-4xl font-bold">{t('products.inverters.title')}</h2>
              <p className="text-lg text-muted-foreground">
                Convert DC to AC power with maximum efficiency. Our smart and hybrid inverters come with advanced monitoring, battery management, and protection features.
              </p>
              <div className="grid md:grid-cols-2 gap-4">
                {[
                  { title: "On-Grid Inverters", desc: "Grid-tied systems with net metering" },
                  { title: "Hybrid Inverters", desc: "Smart battery backup with grid connectivity" },
                  { title: "Off-Grid Inverters", desc: "Complete energy independence" },
                  { title: "Micro Inverters", desc: "Panel-level optimization" }
                ].map((type, index) => (
                  <div key={index} className="p-4 bg-white dark:bg-gray-900 rounded-lg shadow-md hover:shadow-lg transition-all">
                    <h4 className="font-bold text-foreground mb-2">{type.title}</h4>
                    <p className="text-sm text-muted-foreground">{type.desc}</p>
                  </div>
                ))}
              </div>
              <div className="space-y-3 pt-4">
                {[
                  "Smart and Hybrid inverter technology",
                  "98%+ conversion efficiency",
                  "WiFi & mobile app monitoring",
                  "Battery management system",
                  "5-10 year warranty",
                  "Overload & short circuit protection"
                ].map((feature, index) => (
                  <div key={index} className="flex items-center gap-3">
                    <CheckCircle className="w-5 h-5 text-secondary flex-shrink-0" />
                    <span className="text-foreground">{feature}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Batteries & Storage */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4">{t('products.storage.title')}</h2>
            <p className="text-xl text-muted-foreground">{t('products.storage.subtitle') || 'Store solar energy for use anytime - day or night'}</p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                icon: Battery,
                title: "Lithium-Ion Batteries",
                capacity: "5-15 kWh",
                cycles: "6000+ cycles",
                warranty: "10 years",
                features: ["Smart BMS", "Fast charging", "80% DoD", "Compact design"]
              },
              {
                icon: Battery,
                title: "Lead-Acid Batteries",
                capacity: "150-250 Ah",
                cycles: "1500+ cycles",
                warranty: "5 years",
                features: ["Cost-effective", "Proven technology", "Easy maintenance", "Wide availability"]
              },
              {
                icon: Shield,
                title: "Battery Management",
                capacity: "Smart Control",
                cycles: "Optimized",
                warranty: "Protected",
                features: ["Real-time monitoring", "Auto protection", "Temperature control", "Charge optimization"]
              }
            ].map((battery, index) => (
              <div 
                key={index}
                className="bg-white dark:bg-gray-900 rounded-2xl p-8 shadow-xl hover:shadow-2xl transition-all hover:-translate-y-2"
              >
                <div className="w-16 h-16 rounded-xl bg-gradient-solar flex items-center justify-center mb-6">
                  <battery.icon className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-2xl font-bold mb-4 text-foreground">{battery.title}</h3>
                <div className="space-y-2 mb-6">
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-muted-foreground">Capacity:</span>
                    <span className="font-semibold text-foreground">{battery.capacity}</span>
                  </div>
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-muted-foreground">Life Cycles:</span>
                    <span className="font-semibold text-foreground">{battery.cycles}</span>
                  </div>
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-muted-foreground">Warranty:</span>
                    <span className="font-semibold text-foreground">{battery.warranty}</span>
                  </div>
                </div>
                <div className="space-y-2">
                  {battery.features.map((feature, idx) => (
                    <div key={idx} className="flex items-center gap-2 text-sm">
                      <CheckCircle className="w-4 h-4 text-primary flex-shrink-0" />
                      <span className="text-muted-foreground">{feature}</span>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Certifications */}
      <section className="py-20 bg-muted/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4">{t('products.certifications.title')}</h2>
            <p className="text-xl text-muted-foreground">{t('products.certifications.subtitle') || 'All products meet international quality standards'}</p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {[
              { title: "IEC Certified", desc: "International standards" },
              { title: "ISO Certified", desc: "Quality management" },
              { title: "CE Marked", desc: "European conformity" },
              { title: "MNRE Approved", desc: "Government recognized" }
            ].map((cert, index) => (
              <div 
                key={index}
                className="text-center p-6 bg-white dark:bg-gray-900 rounded-xl shadow-lg hover:shadow-xl transition-all hover:-translate-y-2"
              >
                <Award className="w-12 h-12 text-primary mx-auto mb-4" />
                <h3 className="font-bold text-foreground mb-2">{cert.title}</h3>
                <p className="text-sm text-muted-foreground">{cert.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-gradient-solar text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            {t('products.cta.title')}
          </h2>
          <p className="text-xl mb-8 opacity-90">
            {t('products.cta.subtitle') || 'Our team will help you choose the perfect solar products for your needs'}
          </p>
          <Button variant="secondary" size="lg" asChild>
            <Link to="/contact">{t('products.cta.btn') || 'Consult Our Experts'}</Link>
          </Button>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Products;
